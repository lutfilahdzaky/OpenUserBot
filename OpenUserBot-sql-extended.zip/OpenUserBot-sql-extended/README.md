<h2 align="center">RizkyBot</h2>
<p align="center"><a href="https://heroku.com/deploy?template=https://github.com/Rizkyawan028/RizkyBotTelegram/tree/sql-extended"> <img src="https://telegra.ph/file/80d098d41fe74c1eee1cb.jpg" alt="Deploy to Heroku" /></a></p>
